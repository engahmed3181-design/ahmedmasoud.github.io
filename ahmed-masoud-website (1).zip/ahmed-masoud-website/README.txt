AHMED MASOUD - FREE PROFESSIONAL WEBSITE

1. Add your own professional portrait to this folder. Name it EXACTLY:
   ahmed-masoud-electrical-engineer.jpg
   Prefer a clear, original, authorized JPG (at least 1000 px wide).
2. Preview by double-clicking index.html.
3. Create a free GitHub account at https://github.com/ if needed.
4. Create a NEW PUBLIC repository named YOURUSERNAME.github.io (replace YOURUSERNAME with your actual GitHub username).
5. Upload index.html and the photo (NOT just this ZIP), commit the files.
6. Repository > Settings > Pages > Build and deployment: Deploy from a branch, main, /(root), Save.
7. Your site should be available at https://YOURUSERNAME.github.io/ after publication.
8. Verify your site in Google Search Console: https://search.google.com/search-console/
   Submit the homepage URL for indexing after the site is live.
9. Add the website URL to your LinkedIn profile. Keep name/profile photo consistent.

SEO NOTES
- Replace portrait placeholder with your OWN photograph before publishing.
- This starter uses descriptive image filename, alt text, page meta description, public indexable HTML and ProfilePage JSON-LD.
- The ProfilePage URL is not hardcoded until you know the final website address.
- If you later use a custom domain, update metadata and site links accordingly.
- Google crawling/indexing/rankings are not guaranteed; Search Console indexing requests do not guarantee appearance or placement.
